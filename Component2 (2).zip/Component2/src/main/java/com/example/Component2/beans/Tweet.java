package com.example.Component2.beans;

import java.util.List;

public class Tweet {

	public int tweetid;
    public String username;
    public int userId;
    public String useremail;
    public String tweetMessage;
    public int tweetLikes;
    public List<Comment> comments;
          
	public Tweet() {
		super();
	}

	public Tweet(int tweetid, String username, int userId, String useremail, String tweetMessage, int tweetLikes,
			List<Comment> comments) {
		super();
		this.tweetid = tweetid;
		this.username = username;
		this.userId = userId;
		this.useremail = useremail;
		this.tweetMessage = tweetMessage;
		this.tweetLikes = tweetLikes;
		this.comments = comments;
	}



	public int getTweetid() {
		return tweetid;
	}

	public void setTweetid(int tweetid) {
		this.tweetid = tweetid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getTweetMessage() {
		return tweetMessage;
	}

	public void setTweetMessage(String tweetMessage) {
		this.tweetMessage = tweetMessage;
	}

	public int getTweetLikes() {
		return tweetLikes;
	}

	public void setTweetLikes(int tweetLikes) {
		this.tweetLikes = tweetLikes;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	  
}
