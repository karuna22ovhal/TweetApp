package com.example.Component2.dao;

public interface TweetDaoInterface {

}
