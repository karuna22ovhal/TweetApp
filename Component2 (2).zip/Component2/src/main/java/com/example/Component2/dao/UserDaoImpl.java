package com.example.Component2.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.Component2.beans.User;
import com.example.Component2.datastorage.Data;

@Repository
public class UserDaoImpl implements UserDaoInterface {
	Data data = new Data();
	ArrayList<User> users = new ArrayList<User>();

	UserDaoImpl() {
		users = data.allUsers();
	}

	public void registerUser(User user) {
		users.add(user);
		System.out.println("User registered");
	}

	public User authenticate(String email, String password) {
		ArrayList<User> userlist = users;
		for (User curuser : userlist) {
			if (curuser.getEmail().equals(email) && curuser.getPassword().equals(password)) {
				System.out.println("hi " + curuser.email);
				return curuser;
			}
		}
		return null;
	}

	public List<User> allUsers() {
		return this.users;
	}

}
