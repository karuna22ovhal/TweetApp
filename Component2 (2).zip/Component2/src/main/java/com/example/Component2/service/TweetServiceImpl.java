package com.example.Component2.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Component2.beans.Comment;
import com.example.Component2.beans.Tweet;
import com.example.Component2.dao.TweetDaoImpl;


@Service
public class TweetServiceImpl  implements TweetServiceInterface {
	
	@Autowired
	public TweetDaoImpl tweetDaoImpl;
	
	public ArrayList<Tweet> getTweets(String type) {
		return tweetDaoImpl.allTweets(type);
	}
	
	public String postTweet(Tweet tweet) {
		return tweetDaoImpl.postTweet(tweet);
	}
	
	public Tweet addComment(Comment comment,String tweettype,int tweetid){
		return tweetDaoImpl.addComment(comment,tweettype,tweetid);
	}


}
