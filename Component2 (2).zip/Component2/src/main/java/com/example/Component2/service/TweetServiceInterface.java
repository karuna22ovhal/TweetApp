package com.example.Component2.service;

import java.util.ArrayList;

import com.example.Component2.beans.Tweet;

public interface TweetServiceInterface {
	
	public ArrayList<Tweet> getTweets(String type);

}
