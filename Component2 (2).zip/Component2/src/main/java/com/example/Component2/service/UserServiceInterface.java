package com.example.Component2.service;

import java.util.List;

import com.example.Component2.beans.User;

public interface UserServiceInterface {
	
	public void registerUser(User user);
	public User authenticate(String email,String password);
	public List<User> allUsers();

}
