package com.example.Component2.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Component2.beans.Comment;
import com.example.Component2.beans.Tweet;
import com.example.Component2.service.TweetServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class TweetController {
	
	@Autowired
	public TweetServiceImpl tweetService;
	
	@GetMapping("/api/v1.0/twitter/tweets/all")
	public ArrayList<Tweet> getMyTweets(@RequestParam() String type) {
		return tweetService.getTweets(type);
	} 
	
	@PostMapping("/api/v1.0/twitter/username/add")
	public String postTweet(@RequestParam("username") String email,@RequestBody Tweet tweet){
		tweetService.postTweet(tweet);
		return "new tweet posted";
	}
	
	@PostMapping("/api/v1.0/twitter/username/reply")
	public Tweet addComment(@RequestBody Comment comment,@RequestParam() String tid,@RequestParam() String tweettype){
		int tweetid=Integer.parseInt(tid);  
		Tweet t=tweetService.addComment(comment,tweettype,tweetid);
		return t;
	}

}
