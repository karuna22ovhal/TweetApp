package com.example.Component2.dao;

import java.util.ArrayList;

import org.springframework.stereotype.Repository;

import com.example.Component2.beans.Comment;
import com.example.Component2.beans.Tweet;
import com.example.Component2.datastorage.Data;


@Repository
public class TweetDaoImpl implements TweetDaoInterface {

	Data data = new Data();
	ArrayList<Tweet> mytweets = new ArrayList<Tweet>();
	ArrayList<Tweet> alltweets = new ArrayList<Tweet>();

	TweetDaoImpl() {
		mytweets = data.myTweets();
		alltweets = data.allTweets();
	}

	public ArrayList<Tweet> allTweets(String type) {
		if (type.equals("mytweets"))
			return mytweets;
		else if (type.equals("alltweets"))
			return alltweets;
		return alltweets;
	}

	public String postTweet(Tweet tweet) {
		this.mytweets.add(tweet);
		return "tweet posted";
	}

	public Tweet addComment(Comment comment, String tweettype, int tweetid) {
		Tweet t=new Tweet();
		if (tweettype.equals("mytweets")) {
			for (Tweet curtweet : mytweets) {
				if (curtweet.getTweetid() == tweetid) {
					curtweet.getComments().add(comment);
					t=curtweet;
				}
			}
		} else if (tweettype.equals("alltweets")) {
			for (Tweet curtweet : alltweets) {
				if (curtweet.getTweetid() == tweetid) {
					curtweet.getComments().add(comment);
					t=curtweet;
				}
			}
		}
		return t;
	}}
