package com.example.Component2.dao;

import com.example.Component2.beans.User;

public interface UserDaoInterface {
	
	public void registerUser(User user);
	public User authenticate(String email,String password);

}
