package com.example.Component2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Component2.beans.User;
import com.example.Component2.dao.UserDaoImpl;

@Service
public class UserServiceImpl implements UserServiceInterface {
	@Autowired
	public UserDaoImpl userDaoImpl;
	
	public void registerUser(User user) {
		userDaoImpl.registerUser(user);
	}
	
	public User authenticate(String email,String password) {
		return userDaoImpl.authenticate(email,password);
	}
	
	public List<User> allUsers(){
		return userDaoImpl.allUsers();
	}
}


