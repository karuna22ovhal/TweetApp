package com.tweetapp.controller;

import java.net.IDN;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.model.AuthenticationRequest;
import com.tweetapp.model.AuthenticationResponse;
import com.tweetapp.model.UserModel;
import com.tweetapp.repository.UserRepository;
//import com.tweetapp.repository.UserRepositoryy;
import com.tweetapp.service.EmailService;
import com.tweetapp.service.UserService;
import com.tweetapp.utils.JwtUtils;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping(value = "/api/v1.0/tweets")
public class AuthController {
	Random random = new Random(1000);

	@Autowired
	public EmailService emailService;

	@Autowired
	public UserRepository userRepository;

	@Autowired
	public UserService userService;

	@Autowired
	public AuthenticationManager authenticationManager;

	@Autowired
	public JwtUtils jwtUtils;

	@PostMapping(value = "/register")
	private ResponseEntity<?> subscribeClient(@RequestBody UserModel userModel) {
		String email = userModel.getEmail();
		try {
			userRepository.save(userModel);
			
		} catch (Exception e) {
			return ResponseEntity.ok(new AuthenticationResponse("Error during Client Subscription" + email));
		}
		return ResponseEntity.ok(new AuthenticationResponse("Successfull Subscription For Client" + email));
	}

	@GetMapping(value = "/users/all")
	public ResponseEntity<List<UserModel>> getAllUsers() {
		return ResponseEntity.ok(userService.getAllUsers());
	}

	@PutMapping(value = "/reset")
	public ResponseEntity resetPassword(@RequestBody UserModel userModel) {
		userService.resetPassword(userModel);
		return ResponseEntity.ok().build();
	}

	@GetMapping("/users/{email}")
	public ResponseEntity<UserModel> getUsersByEmail(@PathVariable String email) {
		return ResponseEntity.ok(userService.getUsersByEmail(email));
	}

//	@PostMapping("/login")
//	private ResponseEntity<?> authenticateClient(@RequestBody AuthenticationRequest authenticationRequest) {
//		String email = authenticationRequest.getEmail();
//		String password = authenticationRequest.getPassword();
//		System.out.println(email);
//		System.out.println(password);
//		try {
//
//			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));
//
//		} catch (Exception e) {
//			return ResponseEntity.ok("");
//		}
//
//		UserDetails loadedUser = userService.loadUserByUsername(email);
//		String generatedToken = jwtUtils.generateToken(loadedUser);
//		return ResponseEntity.ok(new AuthenticationResponse(generatedToken));
//	}
	
	@PostMapping("/login")
	private boolean authenticateClient(@RequestBody AuthenticationRequest authenticationRequest) {
		String email = authenticationRequest.getEmail();
		String password = authenticationRequest.getPassword();
		List<UserModel> allUsers = userService.getAllUsers();
		for(int index = 0; index < allUsers.size();index ++) {
			if(allUsers.get(index).getEmail().equals(email) && allUsers.get(index).getPassword().equals(password)) {	
				System.out.println("yes");				
				return true;				
			}
		}		
		System.out.println("no");		
		return false;
	}
	
	@GetMapping("/forgot/{email}")
	private ResponseEntity<?> sendOTP(@PathVariable String email) {

		System.out.println("Email " + email);
		
		int otp = random.nextInt(999999);
		System.out.println("OTP  " + otp);
		String subject = "OTP From Tweet App";
		String message = "Your OTP is" + otp;
		String to = email;
		boolean flag = this.emailService.sendEmail(subject, message, to);
		if (flag) {

			return ResponseEntity.ok(otp);
		} else {
			return ResponseEntity.ok(new AuthenticationResponse("NOOO"));
		}

	}

	public static String toIdnAddress(String mail) {
		if (mail == null) {
			return null;
		}
		int idx = mail.indexOf('@');
		if (idx < 0) {
			return mail;
		}
		return localPart(mail, idx) + "@" + IDN.toASCII(domain(mail, idx));
	}

	private static String localPart(String mail, int idx) {
		return mail.substring(0, idx);
	}

	private static String domain(String mail, int idx) {
		return mail.substring(idx + 1);
	}

	@GetMapping("/test")
	public String handleTest() {
		return "this is project using sts" + SecurityContextHolder.getContext().getAuthentication().getName();
	}

}
