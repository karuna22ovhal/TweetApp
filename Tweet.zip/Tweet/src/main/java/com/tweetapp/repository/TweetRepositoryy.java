package com.tweetapp.repository;

//import java.util.List;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.data.mongodb.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.tweetapp.model.TweetModel;
//
//@Repository
//public interface TweetRepositoryy extends MongoRepository<TweetModel, Long> {
//	
//	@Query("{'email':?0}")
//	List<TweetModel> findUserByEmail(String email);
//
//}
