
public class DatabaseConnection {
	
	public static void forName(String className)throws ClassNotFoundException  
	try {
		
	
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	}
}

