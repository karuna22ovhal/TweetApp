package com.tweetapp.Entity;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tweet")

public class userTweet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Integer id;
	@ManyToOne
	@JoinColumn(name="user_id")
	private UserRegister userId;
	
	@Column(name="tweet_text")
	private String tweetText;
	
	@Column(name="tweet_date")
	private LocalDate tweetDate;
	
	@Column(name="tweet_time")
	private LocalTime tweetTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public UserRegister getUserId() {
		return userId;
	}

	public void setUserId(UserRegister userId) {
		this.userId = userId;
	}

	public String getTweetText() {
		return tweetText;
	}

	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}

	public LocalDate getTweetDate() {
		return tweetDate;
	}

	public void setTweetDate(LocalDate tweetDate) {
		this.tweetDate = tweetDate;
	}

	public LocalTime getTweetTime() {
		return tweetTime;
	}

	public void setTweetTime(LocalTime tweetTime) {
		this.tweetTime = tweetTime;
	}


}
