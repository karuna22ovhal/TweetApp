package com.tweetapp.Service;

import com.tweetapp.Entity.UserRegister;
import com.tweetapp.dao.UserRegisterDao;

public interface TweetappService {

	
	public String registeruser(UserRegisterDao userregister);
	
	
}
