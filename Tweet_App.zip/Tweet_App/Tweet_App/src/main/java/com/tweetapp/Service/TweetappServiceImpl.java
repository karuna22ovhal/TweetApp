package com.tweetapp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.Entity.UserRegister;
import com.tweetapp.dao.UserRegisterDao;
import com.tweetapp.repository.RegisterRepository;
@Service
public class TweetappServiceImpl implements TweetappService {
	
	@Autowired 
	RegisterRepository registerRepo;

	@Override
	public String registeruser(UserRegisterDao userregister) {
		String response="";
	UserRegister register=new UserRegister();
	register.setFirstName(userregister.getFirstName());
	register.setLastName(userregister.getLastName());
	register.setGender(userregister.getGender());
	register.setDob(register.getDob());
	register.setEmail(userregister.getEmail());
	register.setPassword(userregister.getPassword());
	
	UserRegister reg2=  registerRepo.save(register);
	if(reg2!=null) {
		response=" User Register Successfully ..!! ";
		
	}
	else {
		response=" There is an issue with register ,Please check input ! ";
		
	}
	return response;
		
	}

}
