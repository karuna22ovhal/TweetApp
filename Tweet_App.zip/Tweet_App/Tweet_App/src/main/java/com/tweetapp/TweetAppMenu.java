package com.tweetapp;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tweetapp.Service.TweetappService;
import com.tweetapp.Service.TweetappServiceImpl;
import com.tweetapp.dao.UserRegisterDao;
import com.tweetapp.repository.RegisterRepository;

@Component
public class TweetAppMenu {
	/*
	 * @Autowired public RegisterRepository registerRepo;
	 */

	@Autowired
    TweetappService tweetService;
	public String saveUser(UserRegisterDao pojo)
	{

	   
		return tweetService.registeruser(pojo);
	}
	
	public  void  menus()
	{
		int ch=0;
		DateTimeFormatter formater=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		TweetAppMenu menu=new TweetAppMenu();
	
		do {
			
			Scanner in =new Scanner(System.in);
		
		      System.out.println("\n***Welcome to the Tweet App***");
		       System.out.println("\n\n\t1.  Please select below menu option (1,2 or 3)\n"
				+"\t2. Register\n"
				+"\t3. Login\n"
				+"\t4. Forgot Password\n");
		   	ch=in.nextInt();
		       switch(ch)
				{
				
		       case 1:
		    	   in =new Scanner(System.in);
		    	   int action=0;
		    	   String firstname="",lastname="",gender="",email="",password="";
		    	   		LocalDate localdate=null;
		    	   do {
		    	   System.out.println("Enter First Name: ");
		    	    firstname=in.nextLine();
		    	   
		    	   System.out.println("Enter Last Name: ");
		    	    lastname=in.nextLine();

		    	   System.out.println("Enter Gender: ");
		    	    gender=in.nextLine();

		    	   System.out.println("Enter Date Of Birth in dd/MM/yyyy: ");
		    	   String  dob=in.nextLine();
		    	   localdate=LocalDate.parse(dob,formater);

		    	   System.out.println("Enter Email: ");
		    	    email=in.nextLine();
		    	   
		    	   System.out.println("Enter Password: ");
		    	    password=in.nextLine();
		    	   
		    	   System.out.println("You have entered records as follows:\n ");
		    	   System.out.println("First Name="+firstname);
		    	   System.out.println("Last Name="+lastname);
		    	   System.out.println("Gender="+gender);
		    	   System.out.println("Date Of Birth="+dob);
		    	   System.out.println("Email="+email);
		    	   System.out.println("password="+password);
		    	   System.out.println("Press 1 to confirm, 2 to Re Enter");
		    	   action=in.nextInt();
		    	  }
		           while(action!=1);
		    	   UserRegisterDao reg=new UserRegisterDao();
		    	   reg.setFirstName(firstname);
		    	   reg.setLastName(lastname);
		    	   reg.setGender(gender);
		    	   reg.setDob(localdate);
		    	   reg.setEmail(email);
		    	   reg.setPassword(password);
		    	   System.out.println(menu.saveUser(reg));
		    
		           break;
		
		  case 2:
			System.out.println("login");
			break;
		
				}
		}
		while(ch!=10);

	}
}

