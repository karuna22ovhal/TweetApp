package com.tweetapp.dao;

import java.time.LocalDate;
import java.time.LocalTime;

public class UserTweetDao {
	

	private Integer userId;
	private String tweetText;
	private LocalDate tweetDate;
	private LocalTime tweetTime;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTweetText() {
		return tweetText;
	}
	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
	public LocalDate getTweetDate() {
		return tweetDate;
	}
	public void setTweetDate(LocalDate tweetDate) {
		this.tweetDate = tweetDate;
	}
	public LocalTime getTweetTime() {
		return tweetTime;
	}
	public void setTweetTime(LocalTime tweetTime) {
		this.tweetTime = tweetTime;
	}

}
