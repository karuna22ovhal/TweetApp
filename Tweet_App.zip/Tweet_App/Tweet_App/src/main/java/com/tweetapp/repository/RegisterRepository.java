package com.tweetapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tweetapp.Entity.UserRegister;

public interface RegisterRepository extends JpaRepository<UserRegister, Integer> {
	

}
