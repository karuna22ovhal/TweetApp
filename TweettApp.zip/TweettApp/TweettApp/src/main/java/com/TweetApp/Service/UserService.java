package com.TweetApp.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.TweetApp.Dao.UserRegisterDao;
import com.TweetApp.Dao.UserTweetDao;
import com.TweetApp.db.Database;
import com.mysql.cj.jdbc.result.ResultSetFactory;

import comTweetApp.VO.viewAllUserVO;
import comTweetApp.VO.viewTweetVO;



public class UserService {

	public String registeruser(UserRegisterDao ur) {
		
		int status=0;  
		String response="";
        try{  
        	Database db=new Database();
        	  Connection con=db.CreateConnection(); 
        	
        	PreparedStatement ps=con.prepareStatement(  
                         "insert into user(first_name,last_name,gender,dob,email,password) values (?,?,?,?,?,?)");  
            ps.setString(1,ur.getFirstName());  
            ps.setString(2,ur.getLastName());  
            ps.setString(3,ur.getGender());  
            
            ps.setDate(4,java.sql.Date.valueOf(ur.getDob()));  
            ps.setString(5, ur.getEmail());
            ps.setString(6, ur.getPassword());
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          if(status>=0) {
        	  response="You have register successfully !!";
          }
          else {
        	  response="error"; 
          }
        return response;  
	}
	public Integer LoginUser(String email,String password) {
		int status=0;  
		String response="";
		Integer userId=null;
        try{  
        	Database db=new Database();
        	  Connection con=db.CreateConnection(); 
        	  String checkQuery="select * from user where email=? and password=?";
        	
        	PreparedStatement ps=con.prepareStatement(checkQuery);
        	ps.setString(1, email);
        	ps.setString(2, password);
                        
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
            	userId=rs.getInt("id");
            }
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
         
        return userId;  
		
	}
	
public String PostTweet(Integer userId, String tweetText) {
		
		int status=0;  
		String response="";
        try{  
        	Database db=new Database();
        	  Connection con=db.CreateConnection(); 
        	
        	PreparedStatement ps=con.prepareStatement(  
                         "insert into tweet(user_id,tweet_text,tweet_date,tweet_time) values (?,?,?,?)"); 
        	ps.setInt(1,userId);
            ps.setString(2,tweetText);  
            ps.setDate(3,java.sql.Date.valueOf (LocalDate.now()));  
            ps.setTime(4,java.sql.Time.valueOf(LocalTime.now()));  
            
            status=ps.executeUpdate();  
              
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          if(status>=0) {
        	  response="successfully post a new tweet ..!!";
          }
          else {
        	  response="error in posting tweet"; 
          }
        return response;  
	}

 public List <viewTweetVO> viewmytweetList(Integer userId){
	    
		List<viewTweetVO>  mylist=new ArrayList<>();
		
     try{  
     	Database db=new Database();
     	  Connection con=db.CreateConnection(); 
     	  String checkQuery="select * from tweet where user_id = ?";
     	
     	PreparedStatement ps=con.prepareStatement(checkQuery);
     	ps.setInt(1, userId);           
         ResultSet rs=ps.executeQuery();
         while(rs.next())
         {
        	 
        	 viewTweetVO mytweet=new viewTweetVO();
        	
			
			 mytweet.setTweetText(rs.getString("tweet_text"));
        	 mytweet.setTweetDate(rs.getDate("tweet_date").toLocalDate());
        	 mytweet.setTweetTime(rs.getTime("tweet_time").toLocalTime());
        	 mylist.add(mytweet);
         }
         
           
         con.close();  
     }catch(Exception ex){ex.printStackTrace();}  
      
     return mylist;  
		
 }
 

 public List <viewTweetVO> viewAllTweetList(){
	  
		List<viewTweetVO>  mylist=new ArrayList<>();
		
     try{  
     	Database db=new Database();
     	  Connection con=db.CreateConnection(); 
     	  String checkQuery="select * from tweet";
     	
     	PreparedStatement ps=con.prepareStatement(checkQuery);
         
         ResultSet rs=ps.executeQuery();
         while(rs.next())
         {
        	 
        	 viewTweetVO mytweet=new viewTweetVO();
        	 
			mytweet.setUserName(findAllUser(rs.getInt("user_id")));
			 mytweet.setTweetText(rs.getString("tweet_text"));
        	 mytweet.setTweetDate(rs.getDate("tweet_date").toLocalDate());
        	 mytweet.setTweetTime(rs.getTime("tweet_time").toLocalTime());
        	 mylist.add(mytweet);
         }
         
           
         con.close();  
     }catch(Exception ex){ex.printStackTrace();}  
      
     return mylist;  
		
 }
 public String findAllUser(Integer userId) {
	 
		String userName=null;
     try{  
     	Database db=new Database();
     	  Connection con=db.CreateConnection(); 
     	  String checkQuery="select * from user where id=?";
     	
     	PreparedStatement ps=con.prepareStatement(checkQuery);
     	ps.setInt(1, userId);
                 
         ResultSet rs=ps.executeQuery();
         while(rs.next())
         {
         	userName=rs.getString("first_name");
         	userName=userName+" " + rs.getString("last_name");
         }
           
         con.close();  
     }catch(Exception ex){ex.printStackTrace();}  
      
     return userName;  
		
	}
	
 
 /**view all user *\
  * 
  */
 public List <viewAllUserVO> getAllUserList() {
	 
	 List userList=new ArrayList<>();
	 
		String userName=null;
  try{  
  	Database db=new Database();
  	  Connection con=db.CreateConnection(); 
  	  String checkQuery="select * from user";
  	
  	PreparedStatement ps=con.prepareStatement(checkQuery);
      
      ResultSet rs=ps.executeQuery();
      while(rs.next())
      {
    	viewAllUserVO vo=new viewAllUserVO();
    	
      	userName=rs.getString("first_name");
      	userName=userName+" " + rs.getString("last_name");
      	vo.setUserName(userName);
      	vo.setEmail(rs.getString("email"));
      	userList.add(vo);
      }
        
      con.close();  
  }catch(Exception ex){ex.printStackTrace();}  
   
  return userList;  
		
	}
	/***reset password */
 public String ResetPassword(String oldPassword,String newPassword,Integer userId) {
	 String status=null;
	 Boolean Flag = false;
	 
     try{  
     	Database db=new Database();
     	  Connection con=db.CreateConnection(); 
     	  String checkQuery="select * from user where id=?";
     	
     	PreparedStatement ps=con.prepareStatement(checkQuery);
     	ps.setInt(1, userId);
                 
         ResultSet rs=ps.executeQuery();
         while(rs.next())
         {
         	if(oldPassword.equals(rs.getString("password")));
         	{
         		//rs.updateObject(7, newPassword);
         		Flag= true;
         		status= "Passoword reset successfully..!!";
         		String updateQuery= "update user set password= ? where id=?";
         		PreparedStatement ps1=con.prepareStatement(updateQuery);
         		ps1.setString(1, newPassword);
         		ps1.setInt(2, userId);
         		ps1.executeUpdate();
         		return "password changed successfully!!";
         	
         	}
         }
           
         con.close();  
     }catch(Exception ex){ex.printStackTrace();}  
      
	 if(!Flag){
		 status= "Old password is Incorrect ..? please enter valid passowrd ";
	 }
	 return status;
 }
 
 public String forgetPassword(String newPassword1,String email) {
	 String status=null;
	 Boolean Flag = false;
	 
     try{  
     	Database db=new Database();
     	  Connection con=db.CreateConnection(); 
     	  String checkQuery="select * from user where email=?";
     	
     	PreparedStatement ps=con.prepareStatement(checkQuery);
     	ps.setString(1, email);
                 
         ResultSet rs=ps.executeQuery();
         while(rs.next())
         {
         	
         		//rs.updateObject(7, newPassword);
         		Flag= true;
         		status= "Passoword reset successfully..!!";
         		String updateQuery= "update user set password= ? where id=?";
         		PreparedStatement ps1=con.prepareStatement(updateQuery);
         		ps1.setString(1, newPassword1);
         		ps1.setInt(2, rs.getInt("id"));
         		ps1.executeUpdate();
         		return "password changed successfully!";
         	
         	
         }
           
         con.close();  
     }catch(Exception ex){ex.printStackTrace();}  
      
	 if(!Flag){
		 status= "User is not Registered";
	 }
	 return status;
 }
 
 
 /***
  * Foget password//
  */
 
}
