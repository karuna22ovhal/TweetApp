package com.TweetApp;


import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.TweetApp.Dao.UserRegisterDao;
import com.TweetApp.Service.UserService;

import comTweetApp.VO.viewAllUserVO;
import comTweetApp.VO.viewTweetVO;


public class TweetAppMenu {
	
	Integer userId=null;
	public String saveUser(UserRegisterDao pojo)
	{
       UserService us=new UserService();
       return us.registeruser(pojo);
	   
	}
	
	public  void  menus()
	{
		int ch=0;
		//DateTimeFormatter formater=DateTimeFormatter.ofPattern("dd/MM/yyyy");
	SimpleDateFormat formater=new SimpleDateFormat("dd/MM/yyyy") ;
		TweetAppMenu menu=new TweetAppMenu();
	
		do {
			
			Scanner in =new Scanner(System.in);
		
		      System.out.println("\n***Welcome to the Tweet App***");
		       System.out.println("\n\n\t.  Please select below menu option (1,2 or 3)\n"
				+"\t1. Register\n"
				+"\t2. Login\n"
				+"\t2. Forgot Password\n");
		   	ch=in.nextInt();
		       switch(ch)
				{
				
		       case 1://Register User
		    	   in =new Scanner(System.in);
		    	   int action=0;
		    	   String firstname="",lastname="",gender="",dob="",email="",password="";
		    	   		Date localdate=null;
		    	   do {
		    	   System.out.println("Enter First Name: ");
		    	    firstname=in.nextLine();
		    	   
		    	   System.out.println("Enter Last Name: ");
		    	    lastname=in.nextLine();

		    	   System.out.println("Enter Gender: ");
		    	    gender=in.nextLine();

		    	   System.out.println("Enter Date Of Birth in dd/MM/yyyy: ");
		    	     dob=in.nextLine();
		    	   try {
					localdate=formater.parse(dob);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

		    	   System.out.println("Enter Email: ");
		    	    email=in.nextLine();
		    	   
		    	   System.out.println("Enter Password: ");
		    	    password=in.nextLine();
		    	   
		    	   System.out.println("You have entered records as follows:\n ");
		    	   System.out.println("First Name="+firstname);
		    	   System.out.println("Last Name="+lastname);
		    	   System.out.println("Gender="+gender);
		    	   System.out.println("Date Of Birth="+dob);
		    	   System.out.println("Email="+email);
		    	   System.out.println("password="+password);
		    	   System.out.println("Press 1 to confirm, 2 to Re Enter");
		    	   action=in.nextInt();
		    	  }
		           while(action!=1);
		    	   UserRegisterDao reg=new UserRegisterDao();
		    	   reg.setFirstName(firstname);
		    	   reg.setLastName(lastname);
		    	   reg.setGender(gender);
		    	   reg.setDob(localdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		    	   reg.setEmail(email);
		    	   reg.setPassword(password);
		    	   System.out.println(menu.saveUser(reg));
		    
		           break;
		
		  case 2://LoginUser
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Email");
			email = sc.nextLine();
			System.out.println("Enter Password");
			 password = sc.nextLine();
             UserService userService=new UserService();
             Integer userId = userService.LoginUser(email, password);
            if(userId!=null)
      {
            	int input=0;
	do{
	 sc = new Scanner(System.in);
	System.out.println("Post a tweet - 1");
	System.out.println("View my tweets - 2");
	System.out.println("View all tweets - 3");
	System.out.println("View all Users - 4");
	System.out.println("Reset Password - 5");
	System.out.println("Logout - 6");
	 input = sc.nextInt();
	switch (input) {
	case 1://Post new tweet
			
			System.out.println("Enter the tweet..");
			sc=new Scanner(System.in);
			String tweetText=sc.nextLine();
			UserService service=new UserService();
			String response = service.PostTweet(userId, tweetText);
			System.out.println(response);
			break;
		
		
	case 2:
		//viewMyTweets();
		UserService userservice=new UserService();
		List <viewTweetVO> mylist=userservice.viewmytweetList(userId);
		for(viewTweetVO vo:mylist){
			System.out.println(vo.getTweetText());
			System.out.println(vo.getTweetDate());
			System.out.println(vo.getTweetTime());
		
		}
		
		break;
	case 3:
		//viewAllTweets();
		UserService userservice1=new UserService();
		List <viewTweetVO> mylist1=userservice1.viewAllTweetList();
		for(viewTweetVO vo:mylist1){
			System.out.println("Tweet_By: " +vo.getUserName());
			System.out.println("Tweet: " + vo.getTweetText());
			System.out.println("Tweet_Date : " + vo.getTweetDate());
			System.out.println("Tweet_Time : " + vo.getTweetTime());
			
		}
		
		break;
	case 4:
		//viewAllUsers();
		UserService userservice2=new UserService();
		List <viewAllUserVO> mylist2=userservice2.getAllUserList();
		for(viewAllUserVO vo:mylist2){
			System.out.println("username = "+ vo.getUserName());
			System.out.println("email = " + vo.getEmail());
		
		}
		
		break;
	case 5:
		//resetPassword();
		sc=new Scanner(System.in);
		System.out.println("Enter current password : ");
		String oldPassword = sc.nextLine();
		System.out.println("Enter new password : ");
		String newPassword = sc.nextLine();
		System.out.println("Renter new password.. : ");
		String newPassword2=sc.nextLine();
	   if( newPassword.equals(newPassword2)){
		   String status=userService.ResetPassword(oldPassword, newPassword, userId);
		System.out.println(status);
	   }
	   else{
		   System.out.println("Password not match .. ?please check again");
	   }
		break;
	case 6:
		//logout();
		break;
	
	
	
	
	
	}
	
	
	
	
	
	
}
	while(input!=6);

      }
else 
{
	   System.out.println("Username Or Password is incorrect");
	
}
break;

				

			case 3:System.out.println("Please Enter Registered Email");
			sc=new Scanner(System.in);
			email=sc.nextLine();
			 System.out.println("Enter new Password");
			 password=sc.nextLine();
			 System.out.println("Verify Password");
			 String password2=sc.nextLine();
			 if(password.equals(password2))
			 {
				 UserService service=new UserService();
				 System.out.println(service.forgetPassword(password, email));
			 }
			
		
				}
		}
		
			
		while(ch!=10);

	}
	

	
	public static void main(String []args) {
		TweetAppMenu menu=new TweetAppMenu();
		menu.menus();
	}
}



