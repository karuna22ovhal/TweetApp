package com.TweetApp.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public  class Database {
public static void main (String[]args)
{
	Database db= new Database();
	db.CreateConnection();
}

public static Connection  CreateConnection() {
	Connection con=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con= DriverManager.getConnection("jdbc:mysql://localhost:3306/tweetdb","root","root");
	//System.out.println("db connection success!");
	}catch(ClassNotFoundException ex) {
		Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null,ex);
	} catch (SQLException ex) {
		Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null,ex);
	}
	return con;
}
}
