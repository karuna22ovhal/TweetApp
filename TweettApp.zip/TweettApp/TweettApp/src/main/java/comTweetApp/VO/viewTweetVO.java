package comTweetApp.VO;

import java.time.LocalDate;
import java.time.LocalTime;

public class viewTweetVO {
	private String userName;
	private String tweetText;
	private LocalDate tweetDate;
	private LocalTime tweetTime;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTweetText() {
		return tweetText;
	}
	public void setTweetText(String tweetText) {
		this.tweetText = tweetText;
	}
	public LocalDate getTweetDate() {
		return tweetDate;
	}
	public void setTweetDate(LocalDate tweetDate) {
		this.tweetDate = tweetDate;
	}
	public LocalTime getTweetTime() {
		return tweetTime;
	}
	public void setTweetTime(LocalTime tweetTime) {
		this.tweetTime = tweetTime;
	}
	

}
