package com.tweetapp;

public class App {

	public static void main(String[] args) {
		AppStart appStart=new AppStart();
	}
}
