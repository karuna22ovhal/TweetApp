package com.tweetapp;

import java.util.List;
import java.util.Scanner;

import com.tweetapp.service.TweetService;
import com.tweetapp.service.UserService;

public class AppStart {

	UserService userService = new UserService();
	TweetService tweetService = new TweetService();
	boolean isLoggedin = false;
	String currentuseremail = "";

	AppStart() {
		start();
	}

	public void start() {
		Scanner sc = new Scanner(System.in);
		System.out.println();
		System.out.println("Register - 1");
		System.out.println("Login - 2");
		System.out.println("Forgot Password - 3");
		int input = sc.nextInt();
		switch (input) {
		case 1:
			Register();
			break;
		case 2:
			Login();
			break;
		case 3:
			forgotPassword();
			break;
		default:
			System.out.println("Enter correct option");
			start();
		}
	}

	public void Register() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Username");
		String username = sc.nextLine();
		System.out.println("Enter EmailId(will be used as user ID)");
		String email = sc.nextLine();
		System.out.println("Enter Password");
		String password = sc.nextLine();
		System.out.println("Please tell us your fav movie(for forgot password)");
		String answer = sc.nextLine();
		userService.registerUser(username, email, password, answer);
		Login();
	}

	public void Login() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Email");
		String email = sc.nextLine();
		System.out.println("Enter Password");
		String password = sc.nextLine();

		String currentuseremail = userService.LoginUser(email, password);
		if (currentuseremail != null) {
			isLoggedin = true;
			featureMenu();
		} else {
			System.out.println("Invalid Credentials! Try again.");
			Login();
		}
	}

	public void featureMenu() {
		if (isLoggedin) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Post a tweet - 1");
			System.out.println("View my tweets - 2");
			System.out.println("View all tweets - 3");
			System.out.println("View all Users - 4");
			System.out.println("Reset Password - 5");
			System.out.println("Logout - 6");
			int input = sc.nextInt();
			switch (input) {
			case 1:
				newTweet();
				break;
			case 2:
				viewMyTweets();
				break;
			case 3:
				viewAllTweets();
				break;
			case 4:
				viewAllUsers();
				break;
			case 5:
				resetPassword();
				break;
			case 6:
				logout();
			}
		}
	}

	public void forgotPassword() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmailId");
		String email = sc.nextLine();
		System.out.println("Please tell us your favourite movie");
		String answer = sc.nextLine();

		boolean result = userService.forgotPassword(email, answer);
		if (result) {
			System.out.println("Enter new password");
			String newPassword = sc.nextLine();
			userService.changePassword(email, newPassword);
			System.out.println("Password successfully changed! Please login with new password");
			logout();
		} else {
			System.out.println("Invalid credentials!");
		}
	}

	public void newTweet() {
		Scanner sc = new Scanner(System.in);
		String tweet = sc.nextLine();
		tweetService.postNewTweet(currentuseremail, tweet);
		System.out.println("Tweeted Successfully!");
		featureMenu();
	}

	public void viewMyTweets() {
		List<String> list = tweetService.viewMyTweets(currentuseremail);
		System.out.println("My Tweets");
		System.out.println(list);
		featureMenu();
	}

	public void viewAllTweets() {
		List<String> list = tweetService.viewAllTweets();
		System.out.println("All Tweets");
		System.out.println(list);
		featureMenu();
	}

	public void viewAllUsers() {
		List<String> list = userService.viewAllUsers();
		System.out.println("Users");
		System.out.println(list);
		featureMenu();
	}

	public void resetPassword() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter current password");
		String oldPassword = sc.nextLine();
		System.out.println("Enter new password");
		String newPassword = sc.nextLine();
		userService.resetPassword(currentuseremail, oldPassword, newPassword);
		System.out.println("Password successfully changed! Please login with new password");
		logout();
	}

	public void logout() {
		isLoggedin = false;
		currentuseremail = "";
		start();
	}
}
