package com.tweetapp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.tweetapp.db.ConnectionManager;

public class UserDao {

	ConnectionManager conManager=new ConnectionManager();
	public void registerUser(String username, String email, String password, String answer) {
		Connection con = conManager.getConnection();
		String query = "insert into users (username, email, pass, sec)" + " values (" + username + "," + email + "," +password + "," + answer + ")";
		try {
			Statement statement = con.createStatement();
			statement.executeQuery(query);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public String LoginUser(String email, String password) {
		String res="Invalid Credentials";
		Connection con = conManager.getConnection();
		String query = "SELECT * FROM users WHERE email = '" + email + "' and pass = '" + password + "' ";
		try {
			Statement statement;
			ResultSet resultSet;
			statement = con.createStatement();
			resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				res=resultSet.getString("email");
				return res;
			}
			con.close();
		} catch (SQLException e) {
			return res;
		}
		return res;
	}

	public boolean forgotPassword(String email, String answer) {
		Connection con = conManager.getConnection();
		String query = "SELECT * FROM users WHERE email = '" + email + "' and sec = '" + answer + "' ";
		try {
			Statement statement;
			ResultSet resultSet;
			statement = con.createStatement();
			resultSet = statement.executeQuery(query);
			if (resultSet.getString("email")!=null && resultSet.getString("sec")!=null) {
				return true;
			}
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void changePassword(String email, String password) {
		Connection con = conManager.getConnection();
		String query = "update users set pass = '" + password + "' where emailId = '" + email + "'";
		try {
			Statement statement;
			statement = con.createStatement();
			statement.executeQuery(query);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void resetPassword(String oldPassword, String newPassword, String currentuserEmail) {
		Connection con = conManager.getConnection();
		String query = "update users set pass= '" + newPassword + "' where emailId= '" + currentuserEmail
				+ "' and pass = '" + oldPassword + "'";
		try {
			Statement statement;
			statement = con.createStatement();
			statement.executeQuery(query);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	public List<String> viewAllUsers() {
		List<String> ar=new ArrayList<String>();
		Connection con = conManager.getConnection();
		String query = "SELECT * FROM users";
		try {
			Statement statement;
			ResultSet resultSet;
			statement = con.createStatement();
			resultSet = statement.executeQuery(query);
			while (resultSet.next()) {
				ar.add(resultSet.getString("name"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ar;
	}	
}
