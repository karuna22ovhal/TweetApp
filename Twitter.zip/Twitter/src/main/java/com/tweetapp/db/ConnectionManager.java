package com.tweetapp.db;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionManager {

//	Properties prop=new Properties();
//	FileInputStream ip= new FileInputStream();
	
	private String url = "jdbc:mysql://localhost:3306/db";    
    private String driverName = "com.mysql.jdbc.Driver";   
    private String username = "root";   
    private String password = "root";
    Connection con;

    public Connection getConnection() {
        try {
            Class.forName(driverName);
            try {
                con = DriverManager.getConnection(url, username, password);
            } catch (SQLException ex) {
                System.out.println("Failed to create the database connection."); 
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver not found."); 
        }
        return con;
    }
}
