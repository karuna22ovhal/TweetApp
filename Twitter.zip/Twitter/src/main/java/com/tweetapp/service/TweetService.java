package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;

import com.tweetapp.dao.TweetDao;

public class TweetService {

	TweetDao tweetDao=new TweetDao();
	
	public void postNewTweet(String currentuseremail, String tweet) {
		tweetDao.postNewTweet(currentuseremail,tweet);		
	}

	public List<String> viewMyTweets(String currentuseremail) {
		return tweetDao.viewMyTweets(currentuseremail);
	}
	
	public List<String> viewAllTweets() {
		return tweetDao.viewAllTweets();
	}

}
