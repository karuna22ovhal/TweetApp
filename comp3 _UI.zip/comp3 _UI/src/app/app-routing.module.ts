import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./featuremodules/user/user.module').then(m => m.UserModule)
  },
  {
    path: 'tweet',
    loadChildren: () => import('./featuremodules/tweet/tweet.module').then(m => m.TweetModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
