import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TweetService } from 'src/app/services/tweet.service';

@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss']
})
export class AllUsersComponent implements OnInit {
  viewAllUsers: any;
  fname: any;
  lname: any;
  userEmail: any;
  fullName: any;
  email: any;
  name: any;
  length: any;
  myForm: FormGroup;
  nameSuggestions: any = [];
  showSearchedUser = false;
  keyword = 'name';
  loggedInUser = localStorage.getItem("email");

  constructor(private tweetService: TweetService, private fb: FormBuilder) { }

  ngOnInit(): void {

    this.myForm = this.fb.group({
      searchedUser: ['']
    });
    // this.viewAllUsers = [
    //   {
    //     id: 1,
    //     firstName: "Sagar Verma",
    //     lastName: "Verma",
    //     email: "vermasagar823@gmail.com",
    //     password: "123456",
    //     contactNumber: "123456"
    //   },
    //   {
    //     id: 2,
    //     firstName: "Rahul",
    //     lastName: "Kumar",
    //     email: "kumarrahula823@gmail.com",
    //     password: "123456",
    //     contactNumber: "123456"
    //   },
    //   {
    //     id: 3,
    //     firstName: "Manu",
    //     lastName: "Jain",
    //     email: "vermasagar823@gmail.com",
    //     password: "123456",
    //     contactNumber: "123456"
    //   },
    //   {
    //     id: 4,
    //     firstName: "Piyush",
    //     lastName: "Verma",
    //     email: "vermasagar823@gmail.com",
    //     password: "123456",
    //     contactNumber: "123456"
    //   }

    // ]

    this.tweetService.viewallUsers().subscribe(
      data => {
        this.viewAllUsers = data;
        this.length = this.viewAllUsers.length;
        for (let i = 0; i < this.length; i++) {
          this.fname = this.viewAllUsers[i].firstName;
          this.lname = this.viewAllUsers[i].lastName;
          this.userEmail = this.viewAllUsers[i].email;
          this.fullName =
          {
            email: this.userEmail,
            name: this.fname + " " + this.lname
          }
          this.nameSuggestions.push(this.fullName);
        }
      },
      error => {
        console.log(error.error);
        
      }
    )
  }

  selectEvent(item) { }

  onChangeSearch(search: string) { }

  onFocused(e) { }

  onSubmit(): void {
    this.email = this.myForm.value.searchedUser.email;
    this.name = this.myForm.value.searchedUser.name;
    if (this.email == undefined || this.email === '' || this.email == null) {
      this.showSearchedUser = false;
    } else {
      this.showSearchedUser = true;
    }
  }
}