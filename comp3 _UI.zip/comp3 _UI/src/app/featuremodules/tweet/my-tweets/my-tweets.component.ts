import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TweetService } from 'src/app/services/tweet.service';

@Component({
  selector: 'app-my-tweets',
  templateUrl: './my-tweets.component.html',
  styleUrls: ['./my-tweets.component.scss']
})
export class MyTweetsComponent implements OnInit {
  viewAllTweets: any;
  viewAllReply: any;
  commentBox: any;
  editIndex: any;
  tweetId: any;
  replyId:any;
  singleData:any=[];
  replyForm: FormGroup;
  editYourTweet = true;
  commentOnTweet = true;
  showSearchedUser = false;  
  date = new Date();
  loggedInUser = localStorage.getItem("email");  
  updateTweet = new FormGroup({
    tweetPost: new FormControl('')
  });

  constructor(private tweetService: TweetService, private fb: FormBuilder, private toastr: ToastrService,private router:Router) { }

  ngOnInit(): void {

    this.replyId = Math.floor(Math.random() * (999 - 100 + 1) + 100);

    // this.singleData = [
    //   {
    //     id: 1,
    //     email: "vermasagar@123gmail.com",
    //     tweetPost: "Nice day",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermasahil@123gmail.com","vermaaarti@123gmail.com"]
    //   },
    //   {
    //     id: 2,
    //     email: "vermasagar@123gmail.com",
    //     tweetPost: "last day at office",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com"]
    //   },
    //   {
    //     id: 3,
    //     email: "vermasagar@123gmail.com",
    //     tweetPost: "Nice weather!",
    //     date: new Date(),
    //     likeBy: ["vermapiyush@123gmail.com","vermaaarti@123gmail.com"]
    //   }
    // ];
    // this.viewAllReply = [
    //   {
    //     id: 1,
    //     tweetId: 1,
    //     email: "xyz@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 2,
    //     tweetId: 1,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   },
    //   {
    //     id: 3,
    //     tweetId: 2,
    //     email: "xyz2@gmail.com",
    //     tweetReply: "oh ok nice",
    //     date: new Date
    //   },
    //   {
    //     id: 3,
    //     tweetId: 2,
    //     email: "xyz3@gmail.com",
    //     tweetReply: "yes it is",
    //     date: new Date
    //   }
    // ];

    this.tweetService.viewallTweets().subscribe(
      data => {
      this.viewAllTweets = data;
      console.log(this.viewAllTweets);
      for(let x=0;x<this.viewAllTweets.length;x++){
        if(this.viewAllTweets[x].email==this.loggedInUser){
          this.singleData.push(this.viewAllTweets[x])
        }
      }
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.tweetService.viewallReply().subscribe(
      data => {
        this.viewAllReply = data;
        console.log(this.viewAllReply);
      },
      error => {
        console.log(error.error);
        
      }
    );

    this.replyForm = this.fb.group({
      tweetReply: ['', Validators.required],
    });

  }

  showToaster(): void {
    this.toastr.success("Tweet Edited Successfully !!");
  }

  comment(id, i): void {
    this.commentBox = i;
    this.tweetId = id;
    if (this.commentOnTweet) {
      this.commentOnTweet = false;
    }
    else {
      this.commentOnTweet = true;
    }
  }

  onReply(form: FormGroup): void {
    console.log('reply', form.value.tweetReply);
    let newReply = {
      id: this.replyId,
      tweetId: this.tweetId,
      email: localStorage.getItem("email"),
      tweetReply: form.value.tweetReply,
      date: this.date
    };
    console.log(newReply);
    this.tweetService.replyTweet(newReply).subscribe(
      data => {
        console.log(data);
        this.ngOnInit();
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  delete(tweet): void {
    this.tweetService.deleteTweet(tweet.id).subscribe(response => {
      this.viewAllTweets = this.viewAllTweets.filter(item => item.id !== tweet.id);
    });
    this.tweetService.deleteTweetReply(tweet.id).subscribe(response => {
      console.log(response);
    },
    error => {
      console.log(error.error);
    }
   );
  }

  edit(tweet, i): void {
    this.editIndex = i;
    if (this.editYourTweet) {
      this.editYourTweet = false;
    }
    else {
      this.editYourTweet = true;
    }
    this.updateTweet = new FormGroup({
      tweetPost: new FormControl(tweet['tweetPost']),
    });
  }

  updateYourTweet(tweet): void {
    console.log(this.updateTweet.value.tweetPost);
    let editedTweet = {
      id: tweet.id,
      email: tweet.email,
      tweetPost: this.updateTweet.value.tweetPost,
      date: this.date,
      likeBy: tweet.likeBy
    };
    console.log(editedTweet);
    this.tweetService.putTweet(tweet.id, editedTweet).subscribe(
      data => {
        console.log(data);
        this.showToaster();
        this.ngOnInit();
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  like(tweet): void {
    console.log(tweet.likeBy);
    if (tweet.likeBy.includes(localStorage.getItem("email"))) {
      tweet.likeBy.pop(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy: tweet.likeBy
      };
      console.log(newLike);
      this.tweetService.putTweet(tweet.id, newLike).subscribe(
        data => {
          console.log(data);
        },
        error => {
          console.log(error.error);
          
        }
      );
    }
    else {
      tweet.likeBy.push(localStorage.getItem("email"));
      console.log(tweet.likeBy);
      let newLike = {
        id: tweet.id,
        email: tweet.email,
        tweetPost: tweet.tweetPost,
        date: tweet.date,
        likeBy: tweet.likeBy
      };
      console.log(newLike);
      // this.tweetService.putTweet(tweet.id, newLike).subscribe(
      //   data => {
      //     console.log(data);
      //   },
      //   error => {
      //     console.log(error.error);
      //     
      //   }
      // );
    }
  }
}

