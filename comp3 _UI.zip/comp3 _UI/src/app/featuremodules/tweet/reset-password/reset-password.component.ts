import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { TweetService } from 'src/app/services/tweet.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  myForm: FormGroup;
  viewUser: any;
  new: any;
  loggedInUser = localStorage.getItem("email");

  constructor(private authenticationService: AuthenticationService, private tweetService: TweetService, private toastr: ToastrService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      currentPassword: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  showToaster(): void {
    this.toastr.success("Password Changed Successfully");
  }

  onSubmit(form: FormGroup): void {
    console.log('form value', form.value);
    let credentials = {
      email: this.loggedInUser,
      password: form.value.currentPassword,
    };
    this.new = form.value.newPassword;
    console.log(credentials)
    this.authenticationService.generateToken(credentials).subscribe(
      (data: any) => {
        if (data.response != null||data.response!=undefined||data.response!=='') {
          this.resetPassword(this.new);
        }
        else {
          window.alert("wrong");
        }
      },
      error => {
        console.log(error);
        window.alert("wrong");
      }
    )
  }

  resetPassword(newPwd): void {
    this.tweetService.getUser(this.loggedInUser).subscribe(
      data => {
        this.viewUser = data;
        console.log(this.viewUser[0].id);
        this.reset(newPwd);
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  reset(newPwd): void {
    let reset = {
      id: this.viewUser[0].id,
      firstName: this.viewUser[0].firstName,
      lastName: this.viewUser[0].lastName,
      email: this.viewUser[0].email,
      password: newPwd,
      contactNumber: this.viewUser[0].contactNumber,
    };
    console.log(reset);
    this.tweetService.resetPassword(reset).subscribe(
      data => {
        this.showToaster();
        console.log(data);
      },
      error => {
        console.log(error.error);
        
      }
    );
  }
}