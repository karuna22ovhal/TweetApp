import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AllUsersComponent } from "./all-users/all-users.component";
import { HomeComponent } from "./home/home.component";
import { MyTweetsComponent } from "./my-tweets/my-tweets.component";
import { ResetPasswordComponent } from "./reset-password/reset-password.component";
import { SearchUserTweetComponent } from "./search-user-tweet/search-user-tweet.component";

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'all-users', component: AllUsersComponent },
  { path: 'my-tweets', component: MyTweetsComponent },
  { path: 'single-user/:email', component: SearchUserTweetComponent },
  { path: 'reset', component: ResetPasswordComponent }
  // { path: '', component: HomeComponent, canActivate:[AuthGuard]  },
  // { path: 'all-users', component: ViewAllUsersComponent, canActivate:[AuthGuard]  },  
  // { path: 'my-tweets', component: ViewMyTweetsComponent, canActivate:[AuthGuard]  },
  // { path: 'single-user/:email', component: SingleUserTweetComponent, canActivate:[AuthGuard]  },
  // { path: 'reset', component: ResetPasswordComponent, canActivate:[AuthGuard]  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TweetRoutingModule { }
