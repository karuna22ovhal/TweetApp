import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TweetRoutingModule } from './tweet-routing.module';
import { TweetComponent } from './tweet.component';
import { HomeComponent } from './home/home.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SearchUserTweetComponent } from './search-user-tweet/search-user-tweet.component';
import { AllUsersComponent } from './all-users/all-users.component';
import { MyTweetsComponent } from './my-tweets/my-tweets.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { ToastrModule } from 'ngx-toastr';
import { SharedModule } from 'src/app/shared/shared.module';
import { DateAgoPipe } from 'src/app/pipes/dateago.pipe';

@NgModule({
  declarations: [TweetComponent, HomeComponent, ResetPasswordComponent, SearchUserTweetComponent, AllUsersComponent, MyTweetsComponent, DateAgoPipe],
  imports: [
    CommonModule,
    TweetRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
    AutocompleteLibModule,
    ToastrModule.forRoot()
  ]
})
export class TweetModule { }
