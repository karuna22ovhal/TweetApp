import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  viewUser: any;
  viewUserEmail: any;
  otp: any;
  showOtp = false;
  showReset = false;
  mismatch = false;
  inputPassword = '';
  inputConfirmPassword = '';
  myForm: FormGroup;
  myOtpForm: FormGroup;
  resetForm: FormGroup;

  constructor(private userService: UserService, private toastr: ToastrService, private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.myForm = this.fb.group({
      email: ['', Validators.required],
    });
    this.myOtpForm = this.fb.group({
      otp: ['', Validators.required],
    });
    this.resetForm = this.fb.group({
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  showToasterNotFound(): void {
    this.toastr.error("User Not Found");
  }

  showToasterOtp(): void {
    this.toastr.error("Wrong OTP");
  }

  showToasterSuccess(): void {
    this.toastr.success("Password Reset Successfully");
  }

  onKey(event: any): void {
    this.inputPassword = event.target.value;
  }

  checkPasswordMismatch(event: any): void {
    this.inputConfirmPassword = event.target.value;
    if (this.inputPassword != this.inputConfirmPassword) {
      this.mismatch = true;
    }
    else {
      this.mismatch = false;
    }
  }

  onSubmit(form: FormGroup): void {
    console.log('Email', form.value.email);
    this.userService.getUser(form.value.email).subscribe(
      data => {
        this.viewUser = data;
        console.log(this.viewUser);
        if (this.viewUser.length) {
          console.log("yes");
          this.viewUserEmail = form.value.email;
          this.forgotPassword(form.value.email);
        }
        else {
          console.log("no");
          this.showToasterNotFound();
        }
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  forgotPassword(email): void {
    this.userService.forgot(email).subscribe(
      data => {
        this.otp = data;
        console.log(this.otp);
        if (this.otp != null || this.otp != undefined || this.otp !== '') {
          this.showOtp = true;
        }
      },
      error => {
        console.log(error.error);
        
      }
    );
  }

  onSubmitOtp(form: FormGroup): void {
    console.log('Otp', form.value.otp);
    if (this.otp == form.value.otp) {
      console.log("match");
      this.showReset = true;
    }
    else {
      console.log("no");
      this.showToasterOtp();
    }
  }

  resetPassword(form: FormGroup): void {
    console.log('password', form.value);
    let reset = {
      id: this.viewUser[0].id,
      firstName: this.viewUser[0].firstName,
      lastName: this.viewUser[0].lastName,
      email: this.viewUser[0].email,
      password: form.value.password,
      contactNumber: this.viewUser[0].contactNumber,
    };
    console.log(reset);
    this.userService.resetPassword(reset).subscribe(
      data => {
        this.resetForm.reset(); 
        this.showToasterSuccess();
        this.router.navigate(['/log-in']);
        console.log(data);
      },
      error => {
        console.log(error.error);
        
      }
    );
  }
}
