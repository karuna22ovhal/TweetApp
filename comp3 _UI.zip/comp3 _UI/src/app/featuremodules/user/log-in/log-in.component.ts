import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.scss']
})
export class LogInComponent implements OnInit {

  credentials = {
    email: '',
    password: ''
  }

  constructor(private toastr: ToastrService, private authenticationService: AuthenticationService, private router: Router) { }

  ngOnInit(): void { }

  showToaster(): void {
    this.toastr.error("Invalid Username/Password");
  }

  onSubmit(): void {
    if ((this.credentials.email != '' && this.credentials.password != '') &&
      (this.credentials.email != null && this.credentials.password != null)) {
      this.authenticationService.generateToken(this.credentials).subscribe(
        (data: any) => {
          if(data){
          console.log(data);
            this.router.navigate(['/tweet']);}
          else {
            this.router.navigate(['']);
          }
        },
        error => {
          console.log(error);
        }
      )
    } else {
      console.log("Fields are empty");
    }
    this.router.navigate(['/tweet']);
  }

}
