export interface Reply {
    id: number;
    tweetId: number;
    email: string;
    tweetReply: string;
    date: Date;
}