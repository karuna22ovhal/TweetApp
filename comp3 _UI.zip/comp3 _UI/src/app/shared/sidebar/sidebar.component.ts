import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchUserTweetComponent } from 'src/app/featuremodules/tweet/search-user-tweet/search-user-tweet.component';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  @Input() loggedInUser = localStorage.getItem("email");
  imgurl="https://st3.depositphotos.com/3369547/12852/v/950/depositphotos_128525738-stock-illustration-woman-female-avatar-isolated.jpg"
  
  constructor(private router:Router) { 
    if(this.router.url.includes(".com")){
      this.imgurl="https://e7.pngegg.com/pngimages/328/599/png-clipart-male-avatar-user-profile-profile-heroes-necktie-thumbnail.png";
    }
  }

  ngOnInit(): void {
  }

}
